"""Recurrent CNN experiment package."""
