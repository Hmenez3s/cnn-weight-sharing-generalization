# Emenda prospectiva — experimento mínimo de generalização

**Registro: 2026-10-15, depois da calibração de duração e antes destes 15 treinamentos e da abertura do teste.** Autorização: mensagem explícita do usuário nesta conversa, posterior ao commit `bbb6fed765bfd772df8559632bf30e6912c667eb`. Este protocolo é restrito a este experimento; não reescreve o desenho A–D ou as famílias históricas da emenda anterior. Configuração operacional fixa: [`protocol.json`](../benchmarks/minimal-generalization-20261015/protocol.json). Interpretação/resultados permanecem somente em `REPORT.md`.

## Pergunta e escolha informada pela exploração

Avaliar ganho de generalização destas configurações de CNN loopada no CIFAR-100 com 10% de treino. **Principal: C8−B8. Secundária: E8−B8.** A prioridade de C foi escolhida **depois** da calibração exploratória de uma seed: C8−B8=+2,24 p.p. e E8−B8=−1,86 p.p. no checkpoint comum de 10.000 updates. Não era hipótese principal anterior à calibração; essas observações não integram as cinco novas seeds.

## Desenho/seleção fixos

- Roster completo: B8/C8/E, largura 32, seeds pareadas 11/23/37/53/71, fração 0,10, split 1729 (4.500 imagens de treino e 5.000 de validação por seed), mesma população/subconjunto/minibatches/augmentation pareados por seed. Ordem fixa por seed: B, C, E.
- 10.000 updates/run, batch 128, SGD momentum 0,9, weight decay 0,0005, FP32/AMP desligado. CosineAnnealingLR com horizonte 10.000 desde o início, sem warmup/restart/extensão. B/C: LR 0,03 e α=0,1. E: LR 0,1, α=0,05, λ=0,75, recall/profundidade variável/perda progressiva habilitados. Nenhum ajuste durante ou depois destes runs.
- Seleção exclusivamente por validação K8 a cada 200 updates, incluindo 10.000. **Regra comum prospectiva: maior acurácia, depois menor CE de validação, depois update mais cedo.** O seletor nativo `amended_v2` permite aplicar a mesma regra a todos: em relação à calibração anterior, o desempate por CE passa a ser explícito também em B/C; não altera seu objetivo/arquitetura/LR.
- Preservar logs por update, configurações, identidades de dados/split/subconjunto, hashes de fonte e checkpoints. Após terminar todos os 15 runs, copiar os 15 checkpoints selecionados para destinos exclusivos e congelar seus hashes/seleção/roster/configurações em um único freeze verificável. Falhas/nonfinite tornam o estudo incompleto; não descartar, substituir ou escolher seeds para caber no orçamento.
- B usa oito blocos independentes; C compartilha um bloco com K8 fixo; E tem recall e objetivo/profundidade efetiva distintos. B/E tiveram seleção própria de LR e E recebeu o único resgate histórico; C herdou o LR de B. Não houve igualdade de tuning histórico. O contraste compara **estas configurações**, não todas as CNNs loopadas versus todas as convencionais.

## Teste e inferência estatística

Só depois do freeze completo/verificado abrir a cópia do **teste limpo oficial**: todos os 15 checkpoints em K8 e C/E também em K32. Sem seleção por teste/modelo/seed/K, sem reabertura para ajustes; CIFAR-100-C permanece proibido. K32 é diagnóstico secundário nos mesmos checkpoints, também medido em validação; ganho ausente em K32 não invalida C8/E8 frente a B8.

Unidade: seed pareada (n=5), nunca imagem. Relatar acurácias por seed, deltas em pontos percentuais, média, desvio amostral (`ddof=1`) e **IC95% bilateral Student t, df=4**, para médias e deltas; pressuposto de distribuição aproximadamente normal dos cinco deltas, poder limitado. Teste principal: diferença C8−B8 no teste oficial; validação é descritiva, pois escolheu checkpoints. Tratamento das duas comparações: **sequência fixa** C primeiro, E depois, com teste bilateral α=0,05; E só recebe interpretação inferencial confirmatória de ganho se C tiver limite inferior do IC95% >0. Mostrar sempre o IC95% nominal de E, identificando-o como descritivo quando a hierarquia não abre. Assim a comparação secundária não penaliza a principal nem cria uma segunda oportunidade irrestrita de sucesso. ICs K32−K8 são diagnósticos nominais, não alegações confirmatórias adicionais.

Recomendação principal restrita ao cenário: **favorável** se o IC95% de C8−B8 no teste estiver inteiramente acima de zero; **desfavorável** se inteiramente abaixo; caso contrário **inconclusiva**. Exigir estudo completo/íntegro e revelar os cinco sinais/efeitos. E recebe seu resultado separado sob a hierarquia. **Não usar margem de não inferioridade de 2 p.p.** A proposta anterior dessa margem não foi adotada. K32 e superioridade computacional não são requisitos de sucesso em generalização.

## Orçamento e limites

150.000 updates. A calibração real levou 737,97 s/3 runs: extrapolação para 15 ≈61,5 min, já incluindo curvas/serialização/avaliação de validação. Acrescentar até 5 min de planejamento para congelamento, cópia/leitura/verificação do teste e avaliação final dos 15 checkpoints: **≈67 min, arredondado a 70 min**, dentro da reserva de 90 min; não é garantia. Registrar custos reais e reavaliar se houver evidência de ultrapassagem substancial, sem reduzir o roster.

Diretório novo exclusivo, cópias train/meta, teste ausente/inacessível no treino e só copiado após freeze; caches privados, CPU 12/16 threads e 50% VRAM por processo na RTX 5090. Rede/downloads proibidos no workload. Preservar todos os artefatos anteriores e nenhum cleanup/reset. Não iniciar Stage 2, matriz completa, CIFAR-100-C ou novos ajustes após abrir o teste. Evidência favorável permite apenas recomendar uma próxima etapa, nunca iniciá-la automaticamente.
